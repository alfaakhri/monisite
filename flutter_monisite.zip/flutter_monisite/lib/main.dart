import 'package:flutter/material.dart';
import 'package:flutter_monisite/NavBottomMain.dart';

import 'package:flutter_monisite/root_page.dart';
import 'package:flutter_monisite/screen/account/AccountScreen.dart';
import 'package:flutter_monisite/screen/history/HistoryScreen.dart';
import 'package:flutter_monisite/screen/home/HomeScreen.dart';
import 'package:flutter_monisite/screen/login/LoginScreen.dart';
import 'package:flutter_monisite/screen/notification/NotificationScreen.dart';
import 'package:flutter_monisite/screen/report/ReportScreen.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: RootPage.id,
      routes: {
        RootPage.id: (context) => RootPage(),
        LoginScreen.id: (context) => LoginScreen(),
        HomeScreen.id: (context) => HomeScreen(),
        HistoryScreen.id: (context) => HistoryScreen(),
        NotificationScreen.id: (context) => NotificationScreen(),
        AccountScreen.id: (context) => AccountScreen(),
        ReportScreen.id: (context) => ReportScreen(),
        NavBottomMain.id: (context) => NavBottomMain(),
      },
    );
  }
}
