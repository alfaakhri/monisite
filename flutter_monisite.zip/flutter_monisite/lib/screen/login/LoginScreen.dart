import 'package:flutter/material.dart';
import 'package:flutter_monisite/NavBottomMain.dart';
import 'package:flutter_monisite/components/style.dart';
import 'package:flutter_monisite/screen/login/ForgotPassScreen.dart';

class LoginScreen extends StatefulWidget {
  static const String id = 'login_screen';

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _obscureText = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      child: Image.asset('images/logo.png'),
                      height: 40.0,
                    ),
                    InkWell(
                      onTap: () {},
                      child: Text(
                        'MoniSite',
                        style: TextStyle(
                          fontSize: 35.0,
                          color: Colors.teal,
                          fontFamily: 'SourceSansPro',
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 48.0,
                ),
                Card(
                  elevation: 4.0,
                  child: Container(
                    margin: EdgeInsets.all(10.0),
                    child: Column(
                      children: <Widget>[
                        TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          textAlign: TextAlign.left,
                          decoration: InputDecorationPlusIconStyle(
                              "Email", Icon(Icons.account_circle)),
                          // new InputDecoration(
                          //     hintText: 'Email',
                          //     icon: new Icon(
                          //       Icons.account_circle,
                          //       color: Colors.grey,
                          //     )),
                          style: TextStyle(
                            color: Colors.black,
                          ),
                          // onChanged: () {
                          //   // email = value;
                          // },
                        ),
                        SizedBox(
                          height: 8.0,
                        ),
                        TextField(
                          obscureText: _obscureText,
                          textAlign: TextAlign.left,
                          decoration: InputDecoration(
                            suffixIcon: GestureDetector(
                              onTap: () {
                                setState(() {
                                  _obscureText = !_obscureText;
                                });
                              },
                              child: Icon(_obscureText
                                  ? Icons.visibility
                                  : Icons.visibility_off),
                            ),
                            icon: Icon(Icons.lock),
                            labelText: 'Enter your password',
                            labelStyle: TextStyle(color: Colors.black),
                            hintStyle: TextStyle(color: Colors.grey),
                          ),
                          style: TextStyle(
                            color: Colors.black,
                          ),
                          onChanged: (value) {
                            // email = value;
                          },
                        ),
                        SizedBox(
                          height: 8.0,
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.pushNamed(context, ForgotPassScreen.id);
                          },
                          child: Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                              'Forget Password ?',
                              textAlign: TextAlign.end,
                              style: TextStyle(
                                color: Colors.blueAccent,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 24.0,
                        ),
                        Container(
                          width: double.infinity,
                          margin: EdgeInsets.symmetric(vertical: 10.0),
                          child: Material(
                            elevation: 5.0,
                            child: RaisedButton(
                              color: Colors.blueAccent,
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                              onPressed: () {
                                Navigator.pushNamed(context, NavBottomMain.id);
                              },
                              child: Text(
                                'Log in',
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
