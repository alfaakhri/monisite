import 'package:flutter/material.dart';

class ReportScreen extends StatefulWidget {
  static const String id = "report_screen";

  @override
  _ReportScreenState createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("Report"),
    );
  }
}