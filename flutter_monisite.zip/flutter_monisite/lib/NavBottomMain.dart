import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import './screen/account/AccountScreen.dart' as account;
import './screen/history/HistoryScreen.dart' as history;
import './screen/home/HomeScreen.dart' as home;
import './screen/report/ReportScreen.dart' as report;
import './screen/notification/NotificationScreen.dart' as notification;


class NavBottomMain extends StatefulWidget {
  static const String id = "nav_bottom_main";

  @override
  _NavBottomMainState createState() => _NavBottomMainState();
}

class _NavBottomMainState extends State<NavBottomMain>
    with SingleTickerProviderStateMixin {
  //create controller untuk tabBar
  TabController controller;

  @override
  void initState() {
    controller = new TabController(vsync: this, length: 5);
    //tambahkan SingleTickerProviderStateMikin pada class _HomeState
    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      //buat body untuk tab viewnya
      body: SafeArea(
        child: new TabBarView(
          //controller untuk tab bar
          controller: controller,
          children: <Widget>[
            //kemudian panggil halaman sesuai tab yang sudah dibuat
            new home.HomeScreen(),
            new report.ReportScreen(),
            new history.HistoryScreen(),
            new account.AccountScreen(),
            new notification.NotificationScreen(),
          ],
        ),
      ),
      bottomNavigationBar: new Material(
        color: Colors.blue,
        child: new TabBar(
          indicatorPadding: EdgeInsets.zero,
          labelPadding: EdgeInsets.zero,
          labelColor: Colors.black,
          unselectedLabelColor: Colors.white,
          controller: controller,
          tabs: <Widget>[
            new Tab(
              child: Text(
                "Home",
                style: TextStyle(fontSize: 16),
              ),
              icon: new Icon(Icons.home,),
            ),
            new Tab(
              child: Text(
                "Report",
                style: TextStyle(fontSize: 16),
              ),
              icon: new Icon(Icons.report),
            ),
            new Tab(
              child: Text(
                "History",
                style: TextStyle(fontSize: 16),
              ),
              icon: new Icon(Icons.history),
            ),
            new Tab(
              child: Text(
                "Notification",
                style: TextStyle(fontSize: 16),
              ),
              icon: new Icon(Icons.notifications),
            ),
            new Tab(
              child: Text(
                "Account",
                style: TextStyle(fontSize: 16),
              ),
              icon: new Icon(Icons.account_circle),
            ),
          ],
        ),
      ),
    );
  }
}
