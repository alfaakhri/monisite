import 'package:flutter/material.dart';
import 'package:flutter_monisite/auth/authentication.dart';
import 'package:flutter_monisite/models/Site.dart';
import 'package:flutter_monisite/screen/home/DetailHomeScreen.dart';
import 'package:flutter_monisite/service/ApiService.dart';

class HomeScreen extends StatefulWidget {
  static const String id = "home_screen";
  final BaseAuth auth;
  final VoidCallback onSignedOut;
  final String userId;

  const HomeScreen({Key key, this.auth, this.onSignedOut, this.userId})
      : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  ApiService apiService;

  @override
  void initState() {
    super.initState();
    apiService = ApiService();
  }

  _signOut() async {
    try {
      await widget.auth.signOut();
      widget.onSignedOut();
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
        child: Column(
          children: <Widget>[
            Container(
              padding: EdgeInsets.symmetric(horizontal: 5.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                border: Border.all(width: 1.0, color: Colors.grey),
              ),
              child: TextField(
                decoration: InputDecoration(
                    hintText: "Cari cluster...", border: InputBorder.none),
              ),
            ),
            SizedBox(
              height: 10.0,
            ),
            Container(
              child: Row(
                children: <Widget>[
                  Icon(Icons.location_on),
                  Text("Jakarta Utara"),
                ],
              ),
            ),
            Expanded(
              child: FutureBuilder(
                future: apiService.getSites(),
                builder:
                    (BuildContext context, AsyncSnapshot<List<Site>> snapshot) {
                  if (snapshot.hasError) {
                    return Center(
                      child: Text(
                          "Something wrong with message: ${snapshot.error.toString()}"),
                    );
                  } else if (snapshot.connectionState == ConnectionState.done) {
                    List<Site> sites = snapshot.data;
                    return _buildListView(sites);
                  } else {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  }
                },
              ),
            ),
            RaisedButton(
              child: Text('Log out'),
              onPressed: _signOut,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListView(List<Site> sites) {
    return Padding(
      padding: EdgeInsets.zero,
      child: ListView.builder(
        itemBuilder: (context, index) {
          Site site = sites[index];
          return Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: InkWell(
              onTap: () {
                var route = new MaterialPageRoute(
                  builder: (BuildContext context) => DetailHomeScreen(
                        id: '${site.id}',
                      ),
                );
                Navigator.of(context).push(route);
              },
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        site.sitename,
                        style: Theme.of(context).textTheme.title,
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      Row(
                        children: <Widget>[
                          Text("Tenant OM: "),
                          Text(site.tenantom),
                        ],
                      ),
                      Text(site.address),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
        itemCount: sites.length,
      ),
    );
  }
}
