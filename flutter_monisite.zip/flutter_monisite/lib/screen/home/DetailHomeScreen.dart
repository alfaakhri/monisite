import 'package:flutter/material.dart';
import 'package:flutter_monisite/models/Site.dart';
import 'package:flutter_monisite/screen/home/MapScreen.dart';
import 'package:flutter_monisite/service/ApiService.dart';

class DetailHomeScreen extends StatefulWidget {
  static const String route = "detail_home_screen";

  final String id;

  const DetailHomeScreen({Key key, this.id}) : super(key: key);

  @override
  _DetailHomeScreenState createState() => _DetailHomeScreenState(this.id);
}

class _DetailHomeScreenState extends State<DetailHomeScreen> {
  ApiService apiService;
  Future<List<Site>> site;
  final String id;

  _DetailHomeScreenState(this.id);

  @override
  void initState() {
    super.initState();
    apiService = ApiService();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Control Panel"),
      ),
      body: FutureBuilder<List<Site>>(
        future: apiService.getSiteById(id),
        builder: (BuildContext context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text(
                  "Something wrong with message: ${snapshot.error.toString()}"),
            );
          } else if (snapshot.hasData) {
            return _buildDetailHomeScreen(snapshot);
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }

  Container _buildDetailHomeScreen(AsyncSnapshot<List<Site>> snapshot) {
    return Container(
      padding: EdgeInsets.all(15.0),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[
            Container(
              child: Text(
                snapshot.data.single.sitename,
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w400),
              ),
            ),
            SizedBox(
              height: 10.0,
            ),
            Row(
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      child: Text("Site ID: ${snapshot.data.single.siteid}"),
                    ),
                    SizedBox(
                      height: 5.0,
                    ),
                    Container(
                      child:
                          Text("Tenant OM: ${snapshot.data.single.tenantom}"),
                    ),
                    SizedBox(
                      height: 5.0,
                    ),
                    Container(
                      width: 250,
                      child: Text(snapshot.data.single.address)),
                  ],
                ),
                SizedBox(width: 20.0,),
                InkWell(
                  onTap: () {
                    var lat =
                        snapshot.data.single.latitude.replaceAll(',', '.');
                    var long =
                        snapshot.data.single.longitude.replaceAll(',', '.');

                    var route = new MaterialPageRoute(
                      builder: (BuildContext context) => MapScreen(
                            latitude: "$lat",
                            longitude: "$long",
                            sitename: "${snapshot.data.single.sitename}",
                          ),
                    );
                    Navigator.of(context).push(route);
                  },
                  child: Icon(Icons.map, size: 36,),
                ),
              ],
            ),
            SizedBox(
              height: 20.0,
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade400,
                borderRadius: new BorderRadius.circular(20.0),
              ),
              padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
              child: Row(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Icon(
                        Icons.ac_unit,
                        size: 28,
                      ),
                      SizedBox(
                        width: 5.0,
                      ),
                      Text(
                        "Suhu",
                        style: TextStyle(fontSize: 32),
                      ),
                      SizedBox(
                        width: 120.0,
                      ),
                      Text(
                        "30",
                        style: TextStyle(fontSize: 26),
                      ),
                      SizedBox(
                        width: 10.0,
                      ),
                      Text("Celcius"),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade400,
                borderRadius: new BorderRadius.circular(20.0),
              ),
              padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
              child: Row(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Icon(
                        Icons.av_timer,
                        size: 28,
                      ),
                      SizedBox(
                        width: 5.0,
                      ),
                      Text(
                        "Tekanan",
                        style: TextStyle(fontSize: 32),
                      ),
                      SizedBox(
                        width: 78.0,
                      ),
                      Text(
                        "30",
                        style: TextStyle(fontSize: 26),
                      ),
                      SizedBox(
                        width: 10.0,
                      ),
                      Text("Psi"),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 10.0,
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade400,
                borderRadius: new BorderRadius.circular(20.0),
              ),
              padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
              child: Row(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Icon(
                        Icons.lightbulb_outline,
                        size: 28,
                      ),
                      SizedBox(
                        width: 5.0,
                      ),
                      Text(
                        "Arus",
                        style: TextStyle(fontSize: 32),
                      ),
                      SizedBox(
                        width: 125.0,
                      ),
                      Text(
                        "30",
                        style: TextStyle(fontSize: 26),
                      ),
                      SizedBox(
                        width: 10.0,
                      ),
                      Text("Ampere"),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 10.0,
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade400,
                borderRadius: new BorderRadius.circular(20.0),
              ),
              padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
              child: Row(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Icon(
                        Icons.flash_on,
                        size: 28,
                      ),
                      SizedBox(
                        width: 5.0,
                      ),
                      Text(
                        "Tegangan",
                        style: TextStyle(fontSize: 32),
                      ),
                      SizedBox(
                        width: 58.0,
                      ),
                      Text(
                        "30",
                        style: TextStyle(fontSize: 26),
                      ),
                      SizedBox(
                        width: 10.0,
                      ),
                      Text("Volt"),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 10.0,
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade400,
                borderRadius: new BorderRadius.circular(20.0),
              ),
              padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
              child: Row(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Icon(
                        Icons.photo,
                        size: 28,
                      ),
                      SizedBox(
                        width: 5.0,
                      ),
                      Text(
                        "Galeri",
                        style: TextStyle(fontSize: 32),
                      ),
                      SizedBox(
                        width: 106.0,
                      ),
                      Text(
                        "30",
                        style: TextStyle(fontSize: 26),
                      ),
                      SizedBox(
                        width: 10.0,
                      ),
                      Text("Foto"),
                    ],
                  ),
                ],
              ),
            ),
            // Expanded(
            //   child: Container(
            //     height: 25.0,
            //     padding: EdgeInsets.symmetric(horizontal: 5.0, vertical: 10.0),
            //     child: Card(
            //       elevation: 3.0,
            //       child: Row(
            //         // mainAxisSize: MainAxisSize.min,
            //         children: <Widget>[
            //           const ListTile(
            //             leading: Icon(Icons.album),
            //             title: Text('Suhu'),
            //           ),
            //           // Text("30"),
            //           // Text("Celcius"),
            //         ],
            //       ),
            //     ),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
