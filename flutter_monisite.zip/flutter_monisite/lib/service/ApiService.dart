import 'package:flutter_monisite/models/Site.dart';
import 'package:http/http.dart' show Client;

class ApiService {

  final String baseUrl = "https://ci-monisite.herokuapp.com/index.php";
  Client client = Client();

  Future<List<Site>> getSites() async {
    final response = await client.get("$baseUrl/site");
    if (response.statusCode == 200) {
      return siteFromJson(response.body);
    } else {
      return null;
    }
  }

  Future<List<Site>> getSiteById(String id) async {
    final response = await client.get("$baseUrl/site?id=$id");
    print("response: $response");
    if (response.statusCode == 200) {
      return siteFromJson(response.body);
    } else {
      return null;
    }
  }
}